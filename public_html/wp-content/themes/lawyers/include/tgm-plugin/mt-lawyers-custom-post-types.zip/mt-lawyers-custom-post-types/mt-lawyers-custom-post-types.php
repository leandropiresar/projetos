<?php
/*
Plugin Name: MT Lawyers Custom Post Types Plugin
Plugin URI: 
Description: The plugin loads the custom post types for MT Lawyers theme
Author: matchthemes
Author URI: http://matchthemes.com
Version: 1.0.0
License: GNU General Public License v3.0
License URI: http://www.opensource.org/licenses/gpl-license.php
*/


// Add Practice Areas Custom Post Type
add_action('init', 'mt_buildPracticeAreas');
function mt_buildPracticeAreas() {
	
		$mt_practice_labels = array(
		'name' => __('Practice Areas', 'match'),
		'singular_name' => __('Practice Item', 'match'),
		'add_new' => __('Add Practice Item', 'match'),
		'add_new_item' => __('Add New Practice Item', 'match'),
		'edit_item' => __('Edit Practice Item', 'match'),
		'new_item' => __('New Practice Item', 'match'),
		'view_item' => __('View Practice Item', 'match'),
		'search_items' => __('Search Practice', 'match'),
		'not_found' =>  __('Nothing found', 'match'),
		'not_found_in_trash' => __('Nothing found in Trash', 'match'),
		'parent_item_colon' => ''
		);
	
    	$mt_practice_args = array(
        	'labels' => $mt_practice_labels,
        	'label' => __('Practice Areas', 'match'),
        	'singular_label' => __('Practice Area', 'match'),
        	'public' => true,
        	'show_ui' => true,
			'menu_icon' => 'dashicons-portfolio',
        	'capability_type' => 'post',
        	'hierarchical' => false,
        	'rewrite' => array('slug' => 'practice-items','with_front' => false),
        	'supports' => array('title', 'editor', 'thumbnail')
        );
		register_post_type('mt_practice_areas',$mt_practice_args);
	
}

// Add Practice Areas Meta Boxes
add_action( 'admin_init', 'mt_practice_areas_custom_meta_boxes' );
function mt_practice_areas_custom_meta_boxes() {
  
  $mt_practice_meta_box = array(
    'id'          => 'mt_practice_meta_box',
    'title'       => __('Item Customization', 'match'),
    'desc'        => '',
    'pages'       => array( 'mt_practice_areas' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
   	  array(
        'label'       => __('Practice Area Font Awesome Icon', 'match'),
        'id'          => 'mt_practice_icon',
        'type'        => 'text',
        'desc'        => __('Add practice area icon code. Please choose the icon from the Font Awesome website ( http://fortawesome.github.io/Font-Awesome/icons/ ) .', 'match'),
        'std'         => 'fa-truck',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  
	  array(
        'label'       => __( 'Use Custom URL', 'match' ),
        'id'          => 'mt_practice_on_off',
        'type'        => 'on-off',
        'desc'        => __( 'Use Custom URL for practice item', 'match' ),
        'std'         => 'off',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  
	  array(
        'label'       => __('Custom URL', 'match'),
        'id'          => 'mt_practice_url',
        'type'        => 'text',
        'desc'        => __('Add custom URL for practice item', 'match'),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      )
	  
  	)
  );
  
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  ot_register_meta_box( $mt_practice_meta_box );

}

// Add Team Custom Post Type
add_action('init', 'mt_buildTeam');
function mt_buildTeam() {
	
		$mt_team_labels = array(
		'name' => __('Team', 'match'),
		'singular_name' => __('Team Item', 'match'),
		'add_new' => __('Add Team Item', 'match'),
		'add_new_item' => __('Add New Team Item', 'match'),
		'edit_item' => __('Edit Team Item', 'match'),
		'new_item' => __('New Team Item', 'match'),
		'view_item' => __('View Team Item', 'match'),
		'search_items' => __('Search Team', 'match'),
		'not_found' =>  __('Nothing found', 'match'),
		'not_found_in_trash' => __('Nothing found in Trash', 'match'),
		'parent_item_colon' => ''
		);
	
    	$mt_team_args = array(
        	'labels' => $mt_team_labels,
        	'label' => __('Team', 'match'),
        	'singular_label' => __('Team', 'match'),
        	'public' => true,
        	'show_ui' => true,
			'menu_icon' => 'dashicons-groups',
        	'capability_type' => 'post',
        	'hierarchical' => false,
        	'rewrite' => array('slug' => 'team','with_front' => false),
        	'supports' => array('title', 'editor', 'thumbnail', 'excerpt')
        );
		register_post_type('mt_team',$mt_team_args);
	
}

// Add Team Meta Boxes
add_action( 'admin_init', 'mt_team_custom_meta_boxes' );

function mt_team_custom_meta_boxes() {
  
  $mt_team_meta_box = array(
    'id'          => 'mt_team_meta_box',
    'title'       => __('Item Customization', 'match'),
    'desc'        => '',
    'pages'       => array( 'mt_team' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
   	  array(
        'label'       => __('Twitter URL', 'match'),
        'id'          => 'mt_team_twitter_url',
        'type'        => 'text',
        'desc'        => __('Add Twitter URL. If the field is empty the button will not be displayed.', 'match'),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  
	  array(
        'label'       => __('Facebook URL', 'match'),
        'id'          => 'mt_team_facebook_url',
        'type'        => 'text',
        'desc'        => __('Add Facebook URL. If the field is empty the button will not be displayed.', 'match'),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  
	  array(
        'label'       => __('Google Plus URL', 'match'),
        'id'          => 'mt_team_gplus_url',
        'type'        => 'text',
        'desc'        => __('Add Google Plus URL. If the field is empty the button will not be displayed.', 'match'),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  
	  array(
        'label'       => __('LinkedIn URL', 'match'),
        'id'          => 'mt_team_linkedin_url',
        'type'        => 'text',
        'desc'        => __('Add LinkedIn URL. If the field is empty the button will not be displayed.', 'match'),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  
	  array(
        'label'       => __('Mail Address', 'match'),
        'id'          => 'mt_team_mail',
        'type'        => 'text',
        'desc'        => __('Add mail address. If the field is empty the button will not be displayed.', 'match'),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  
  	)
  );
  
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  ot_register_meta_box( $mt_team_meta_box );

}

// Add Testimonials Custom Post Type
add_action('init', 'mt_buildTestimonials');
function mt_buildTestimonials() {
	
		$mt_testimonials_labels = array(
		'name' => __('Testimonials', 'match'),
		'singular_name' => __('Testimonial Item', 'match'),
		'add_new' => __('Add Testimonial Item', 'match'),
		'add_new_item' => __('Add New Testimonial Item', 'match'),
		'edit_item' => __('Edit Testimonial Item', 'match'),
		'new_item' => __('New Testimonial Item', 'match'),
		'view_item' => __('View Testimonial Item', 'match'),
		'search_items' => __('Search Testimonials', 'match'),
		'not_found' =>  __('Nothing found', 'match'),
		'not_found_in_trash' => __('Nothing found in Trash', 'match'),
		'parent_item_colon' => ''
		);
	
    	$mt_testimonials_args = array(
        	'labels' => $mt_testimonials_labels,
        	'label' => __('Testimonials', 'match'),
        	'singular_label' => __('Testimonials', 'match'),
        	'public' => true,
        	'show_ui' => true,
			'menu_icon' => 'dashicons-testimonial',
        	'capability_type' => 'post',
        	'hierarchical' => false,
        	'rewrite' => array('slug' => 'testimonials-list','with_front' => false),
        	'supports' => array('title', 'editor', 'thumbnail')
        );
		register_post_type('mt_testimonials',$mt_testimonials_args);
	
}

// Add Testimonials Meta Boxes
add_action( 'admin_init', 'mt_testimonials_custom_meta_boxes' );

function mt_testimonials_custom_meta_boxes() {
    
  $mt_testimonial_meta_box = array(
    'id'          => 'mt_testimonial_meta_box',
    'title'       => __('Item Customization', 'match'),
    'desc'        => '',
    'pages'       => array( 'mt_testimonials' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
   	  array(
        'label'       => __('Client Name', 'match'),
        'id'          => 'mt_testimonial_client_name',
        'type'        => 'text',
        'desc'        => __('Add testimonial client name', 'match'),
        'std'         => 'John Doe',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''       
      ),
	  
	  array(
        'label'       => __('Client Company', 'match'),
        'id'          => 'mt_testimonial_client_company',
        'type'        => 'text',
        'desc'        => __('Add testimonial client company', 'match'),
        'std'         => 'Company Name',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''       
      ),
	  
	  array(
        'label'       => __('Client Small Image', 'match'),
        'id'          => 'mt_testimonial_client_img',
        'type'        => 'upload',
        'desc'        => __('Add testimonial client small image. Make sure is 70x70px.', 'match'),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''       
      )
	  	  
  	)
  );
  
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  ot_register_meta_box( $mt_testimonial_meta_box );

}

// Add Case Results Custom Post Type
add_action('init', 'mt_buildCaseResults');
function mt_buildCaseResults() {
	
		$mt_case_results_labels = array(
		'name' => __('Case Results', 'match'),
		'singular_name' => __('Case Result Item', 'match'),
		'add_new' => __('Add Case Result Item', 'match'),
		'add_new_item' => __('Add New Case Result Item', 'match'),
		'edit_item' => __('Edit Case Result Item', 'match'),
		'new_item' => __('New Case Result Item', 'match'),
		'view_item' => __('View Case Result Item', 'match'),
		'search_items' => __('Search Case Result', 'match'),
		'not_found' =>  __('Nothing found', 'match'),
		'not_found_in_trash' => __('Nothing found in Trash', 'match'),
		'parent_item_colon' => ''
		);
	
    	$mt_case_results_args = array(
        	'labels' => $mt_case_results_labels,
        	'label' => __('Case Results', 'match'),
        	'singular_label' => __('Case Results', 'match'),
        	'public' => true,
        	'show_ui' => true,
			'menu_icon' => 'dashicons-archive',
        	'capability_type' => 'post',
        	'hierarchical' => false,
        	'rewrite' => array('slug' => 'cases','with_front' => false),
        	'supports' => array('title', 'editor', 'thumbnail')
        );
		register_post_type('mt_case_results',$mt_case_results_args);
	
}

// Add Case Results Meta Boxes
add_action( 'admin_init', 'mt_case_results_custom_meta_boxes' );

function mt_case_results_custom_meta_boxes() {
  
  $mt_case_results_meta_box = array(
    'id'          => 'mt_case_results_meta_box',
    'title'       => __('Item Customization', 'match'),
    'desc'        => '',
    'pages'       => array( 'mt_case_results' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
   	  array(
        'label'       => __('Money Result', 'match'),
        'id'          => 'mt_case_money',
        'type'        => 'text',
        'desc'        => __('Add case result settlement.', 'match'),
        'std'         => '$100.000',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  
	  array(
        'label'       => __('The Charges Title', 'match'),
        'id'          => 'mt_case_charges_title',
        'type'        => 'text',
        'desc'        => __('Add charges title.', 'match'),
        'std'         => 'The Charges',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  
	  array(
        'label'       => __('The Charges Text', 'match'),
        'id'          => 'mt_case_charges_text',
        'type'        => 'textarea-simple',
        'desc'        => __('Add charges text.', 'match'),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  
	  array(
        'label'       => __('The Result Title', 'match'),
        'id'          => 'mt_case_result_title',
        'type'        => 'text',
        'desc'        => __('Add result title.', 'match'),
        'std'         => 'The Result',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  
	  array(
        'label'       => __('The Result Text', 'match'),
        'id'          => 'mt_case_result_text',
        'type'        => 'textarea-simple',
        'desc'        => __('Add result text.', 'match'),
        'std'         => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      )
	  
  	)
  );
  
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  ot_register_meta_box( $mt_case_results_meta_box );

}